aws_access_key_id     = "REPLACE_ME"
aws_secret_access_key = "REPLACE_ME"
azure_mysql_admin_username = "REPLACE_ME"