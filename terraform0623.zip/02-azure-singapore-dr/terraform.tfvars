aws_access_key_id     = "AKIA3Z7DDBVQENTFH7JL"
aws_secret_access_key = "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"
azure_mysql_admin_username = "myadmin"