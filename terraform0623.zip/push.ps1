# ============================================================================
# 🚀 Bidhouse 무결점 올인원 전 자동 하이패스 스크립트 (v5 진짜 찐최종형)
# ============================================================================



# 0. 파워쉘 터미널 한글 깨짐 방지용 강제 UTF-8 심폐소생술
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 1. 파워쉘 특수문자 깨짐 방지용 자판기 값 철통 장전
$env:TF_VAR_azure_client_id="21f44982-5230-410e-9ad8-ec033dbfa82b"
$env:TF_VAR_azure_client_secret="rjm8Q~YzkCbqxJ7Hvpf1jpd8vfC~HFsagQa0UahP"
$env:TF_VAR_azure_subscription_id="3d2afd47-a857-4d1b-b894-6fa5a5b4fb7e"
$env:TF_VAR_azure_tenant_id="bca1d08b-353a-45b2-87b1-08dd96e781d1"

Write-Host "🤖 [1단계] 00번 파이프라인 공장 및 S3 금고 상태 자동 점검..." -ForegroundColor Cyan

Push-Location "00-pipeline" 
if (-not (Test-Path ".terraform")) {
    Write-Host "⚙️  00번 방 쌩 백지 상태 감지! 순정 통로 개설 중..." -ForegroundColor Yellow
    terraform init
}
Write-Host "🏗️  00번 공장 및 장부 금고 S3 강제 동기화(Apply) 시동..." -ForegroundColor Yellow
terraform apply -auto-approve

# 00번 방이 만든 따끈따끈한 S3 금고 이름을 실시간으로 탈취합니다. 
$s3_bucket_name = (terraform output -raw global_tfstate_bucket_name)
if ($s3_bucket_name) { $s3_bucket_name = $s3_bucket_name.Trim() }
Pop-Location

# 🔴 [여기가 억까 해체 자물쇠!]
# 00번 방 권한 증서(IAM)가 AWS 서울 본진에 완전히 뿌리내릴 때까지 안전하게 15초간 대기합니다.
Write-Host "⏳ AWS IAM 권한 증서가 본진에 복제될 때까지 15초간 안전하게 대기 중..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

if (-not $s3_bucket_name -or $s3_bucket_name -match "Error" -or $s3_bucket_name -eq "") {
    Write-Host "❌ [비상] S3 백엔드 버킷 이름을 가져오지 못했습니다! 00번 방 설정을 확인하세요." -ForegroundColor Red
    Exit
}

Write-Host "🎯 [2단계] 추출된 S3 금고 주소 획득 완료 -> [$s3_bucket_name]" -ForegroundColor Green
Write-Host "🧹 [4단계] 꼬여버린 깃 캐시 및 하위 모듈 숨은 찌꺼기 완전 세탁..." -ForegroundColor Cyan

# 🔴 [Git Submodule 억까 해결] 각 하위 폴더에 몰래 숨어든 유령 .git 파일/폴더를 추적 물리적 삭제!
foreach ($dir in @("00-pipeline", "01-aws-seoul-network", "02-azure-singapore-dr", "03-cross-cloud", "04-aws-seoul-app-foundation")) {
    if (Test-Path "$dir\.git") { Remove-Item -Recurse -Force "$dir\.git" -ErrorAction SilentlyContinue }
}

Remove-Item -Recurse -Force .git -ErrorAction SilentlyContinue

# 깨끗한 도화지 상태에서 신규 깃 개설
git init -q
git remote add origin https://github.com/minjo46/bidhouse.git
git branch -M main



Write-Host "⚙️  [3단계] 01~04번 방에 S3 금고 고속도로 통로(Init) 원터치 개통식 가동..." -ForegroundColor Cyan

# 🔴 [테라폼 억까 해결] -quiet 플래그를 완전히 제거하여 모든 환경에서 100% 정상 작동 보장!
$target_dirs = @("01-aws-seoul-network", "02-azure-singapore-dr", "03-cross-cloud", "04-aws-seoul-app-foundation")
foreach ($dir in $target_dirs) {
    if (Test-Path $dir) {
        Push-Location $dir
        terraform init -reconfigure -backend-config="bucket=$s3_bucket_name"
        Pop-Location
        Write-Host "🟢 [$dir] 통로 개통 성공!" -ForegroundColor Green
    }
}



# 5. 깔끔하게 싹 긁어모아 깃허브 본진 격발
Write-Host "🚀 [5단계] 깃허브 본진으로 스파이크 발사!!!" -ForegroundColor Magenta

# 🔴 폴더 슬래시 규칙 우회 및 개별 파일 락 해제
git add 00-pipeline/*
git add 01-aws-seoul-network/*
git add 02-azure-singapore-dr/*
git add 03-cross-cloud/*
git add 04-aws-seoul-app-foundation/*
git add app/ 
git add buildspec.yml README.md .gitignore FIXED-DEPLOYMENT-NOTES.md

git commit -m "v5-all-in-one-ultimate" -q
git push origin main -f -q

Write-Host "✨ [상황 종료] 모든 통로 개통 완료 및 깃허브 전송 성공!" -ForegroundColor Green
Write-Host "👉 지금 즉시 AWS 콘솔의 CodePipeline 방으로 가셔서 초록불 축제를 직관하세요!" -ForegroundColor Yellow